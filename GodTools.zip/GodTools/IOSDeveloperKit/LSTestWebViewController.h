//
//  LSTestWebViewController.h
//  IOSDeveloperKit
//
//  Created by LoaforSpring on 16/5/14.
//  Copyright © 2016年 LoaforSpring. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LSWebView.h"

@interface LSTestWebViewController : UIViewController

//web view
@property (nonatomic, strong) LSWebView *webView;

/**
 *  设置webView的地址
 */
@property(nonatomic, strong) NSString *webUrlString;
/**
 *  @brief 标题
 */
@property(nonatomic, strong) NSString *webTitle;

@end

//
//  LSAlertViewDelegate.h
//  iZichanSalary
//
//  Created by LoaforSpring on 16/5/12.
//  Copyright © 2016年 YiZhan. All rights reserved.
//

@protocol LSAlertViewDelegate <NSObject>

@optional
- (void)alertContentViewWillDismiss:(id)object;

@end


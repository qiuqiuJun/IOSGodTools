//
//  ViewController.m
//  IOSDeveloperKit
//
//  Created by LoaforSpring on 16/5/13.
//  Copyright © 2016年 LoaforSpring. All rights reserved.
//

#import "ViewController.h"

#import "LSMacroUtility.h"
#import "LSMacro_NSString.h"

#import "LSSegmentControl.h"

#import "LSToastKit.h"
#import "UIView+LSToastView.h"
#import <objc/runtime.h>

#import "LSFactory.h"
#import "LSTextField.h"
#import "LSScrollView.h"
#import "LSAlertViewKit.h"

@interface ViewController ()
<UITextFieldDelegate, LSTextFieldKeyboardDelegate, LSScrollViewTouchesDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSString *utf8 = LSGetStringUTF8Encoding(@"计算机都开了房");
    NSLog(@"%@", utf8);
    
//    UILabel *label = [LSFactory getLabelWithRect:CGRectMake(10, 30, 100, 20) textFont:LSSystemFontOfSize(18) textColor:[UIColor greenColor] text:@"UIFactory"];
//    [self.view addSubview:label];
    
    UILabel *label = [LSFactory getNoLimitLabelWithWidth:70 originPoint:CGPointMake(10, 30) textFont:LSSystemFontOfSize(16) textColor:[UIColor redColor] text:@"山东矿机科林费斯是看得见风窟窿带神房价多少了九分裤了定时间疯狂揽客东方时空连接断开了是否角度来说开发就当时考虑房价多少开了房"];
    [self.view addSubview:label];
    
    
    LSSegmentControl *segment = [[LSSegmentControl alloc] initSegmentWithTitles:@[@"Title1", @"Title2", @"Title3"]];
    segment.frame = CGRectMake(0, 0, 200, kLSSegmentControlHeight);
    segment.center = CGPointMake(CGRectGetMidX(self.view.frame), CGRectGetMidY(self.view.frame));
    [self.view addSubview:segment];
    
    
    NSLog(@"%f-%f-%f", LSCurrentSystemVersion, LS_SCREEN_MAX_LENGTH, LS_SCREEN_MIN_LENGTH);
    
//    [self.view makeToastActivityWithIntercept:NO];
    
    
    LSTextField *textfield = [[LSTextField alloc] initWithFrame:CGRectMake(20, CGRectGetHeight(self.view.frame)-253+40, 160, 40)];
    textfield.delegate = self;
    textfield.keyboardDelegate = self;
    textfield.layer.borderWidth = 1;
    textfield.bindingView = self.view;
    textfield.layer.borderColor = [UIColor blackColor].CGColor;
    textfield.placeholder = @"测试弹出框覆盖键盘";
    [self.view addSubview:textfield];
    
    
    
    LSScrollView *scrollView = [[LSScrollView alloc] initWithFrame:CGRectMake(20, 60, 280, 100)];
    scrollView.touchDelegate = self;
    scrollView.layer.borderWidth = 1;
    scrollView.layer.borderColor = [UIColor redColor].CGColor;
    scrollView.contentSize = CGSizeMake(280, 200);
    [self.view addSubview:scrollView];
    
//    UIWindow
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [LSToastKit makeToast:@"是咖啡机扣水电费交点水费"];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        __block UIWindow* tempWindow = nil;
        
        [[[UIApplication sharedApplication] windows] enumerateObjectsUsingBlock:^(__kindof UIWindow * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([obj isKindOfClass:NSClassFromString(@"UIRemoteKeyboardWindow")]) {
                tempWindow = obj;
            }
        }];
        if (tempWindow) {
            [tempWindow makeToast:@"提示内容"];
        } else {
            // --没找到键盘
            [self.view makeToast:@"提示内容"];
        }
    });
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
//    [self.view hideToastActivity];
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - LSTextFieldDelegate
- (void)keyboardChangeHeight:(CGFloat)height withDuration:(NSTimeInterval)duration
{
    NSLog(@"height: %f %f", height, duration);
}

#pragma mark - LSScrollViewTouchesDelegate
- (void)scrollViewTouchUpInside:(LSScrollView *)scrollView
{
    NSLog(@"scrollViewTouchUpInside....");
    [LSAlertViewKit showAlertWithTitle:@"Title" message:@"scrollViewTouchUpInside..." cancelButtonTitle:@"OK"];
}

@end

//
//  LSTestWebViewController.m
//  IOSDeveloperKit
//
//  Created by LoaforSpring on 16/5/14.
//  Copyright © 2016年 LoaforSpring. All rights reserved.
//

#import "LSTestWebViewController.h"

#import "LSWebProgressBar.h"
#import "LSMacro_NSString.h"

@interface LSTestWebViewController ()
<UIWebViewDelegate, UIScrollViewDelegate, LSWebViewProgressDelegate>

@property (nonatomic, strong) LSWebProgressBar *progressBar;// 进度条

// 记录是否加载结束
@property (nonatomic, assign) BOOL loadFinished;

@end

@implementation LSTestWebViewController

- (void)dealloc
{
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initWebView];
    
    if (!LSNSStringIsEmpty(self.webUrlString))
    {// 不为空
        [self loadURLWith:self.webUrlString];
    }
    
    if (!LSNSStringIsEmpty(self.webTitle))
    {// 设置网页标题---没有网页标题的时候为它设置一个
        self.title = self.webTitle;
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
//    if (self.loadFinished) {
//        [self.navigationController setNavigationBarHidden:YES animated:animated];
//    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
//    [self.navigationController setNavigationBarHidden:NO animated:animated];
}

- (void)initWebView
{
    self.webView = [[LSWebView alloc] initWithFrame:self.view.frame];
    self.webView.delegate = self;
    self.webView.scrollView.delegate = self;
    self.webView.progressDelegate = self;
    self.webView.backgroundColor = [UIColor whiteColor];
    self.webView.contentMode = UIViewContentModeScaleAspectFill;
    self.webView.scalesPageToFit = YES ;
    self.webView.allowsInlineMediaPlayback = NO;
    self.webView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [self.view addSubview:self.webView];
    
    UIScrollView *scrollView = self.webView.scrollView;
    for (int i = 0; i < scrollView.subviews.count ; i++)
    {
        UIView *view = [scrollView.subviews objectAtIndex:i];
        if ([view isKindOfClass:[UIImageView class]])
        {
            view.hidden = YES ;
        }
    }
}

- (void)viewControllerWillReturn
{
    [self.webView stopLoading];
    self.webView.delegate = nil;
}

- (void)loadURLWith:(NSString*)urlString
{// 不对URL进行编码
    NSLog(@"loadURLPath:%@", urlString);
    
    NSURL *url = [NSURL URLWithString:urlString];
    //检查是否缺少scheme
    if (LSNSStringIsEmpty(url.scheme))
    {
        url = [NSURL URLWithString:[NSString stringWithFormat:@"http://%@", urlString]];
    }
    
    [self loadURL:url];
}

- (void)loadURL:(NSURL *)url
{
    self.progressBar = [[LSWebProgressBar alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.view.bounds.size.width, 2.0f)];
    [self.webView addSubview:self.progressBar];
    
    [self.webView loadRequest:[NSURLRequest requestWithURL:url]];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UIWebViewDelegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSString *urlString = [[request URL] relativeString];
    NSLog(@"urlString:%@---%d--%@", urlString, (int)navigationType, [[request URL] absoluteString]);
    
    // 判断urlString是不是一个URL，，有可能出现-about:blank
    if ([@"about:blank" isEqualToString:urlString])
    {
        return NO;
    }
    
    NSURL *url = [NSURL URLWithString:urlString];
    if ([[url scheme] length]>0)
    {//
    }
    
    switch (navigationType) {
        case UIWebViewNavigationTypeLinkClicked:
        {// 网页内点击了链接
            // 重新创建进度
            self.progressBar.hidden = NO;
            [self.progressBar setProgress:0 animated:YES];
        }
            break;
        case UIWebViewNavigationTypeFormSubmitted:
        {
        }
            break;
        case UIWebViewNavigationTypeBackForward:
        {
        }
            break;
        case UIWebViewNavigationTypeReload:
        {// 刷新了
            self.progressBar.hidden = NO;
            [self.progressBar setProgress:0 animated:YES];
        }
            break;
        case UIWebViewNavigationTypeFormResubmitted:
        {
        }
            break;
        case UIWebViewNavigationTypeOther:
        {// 该页面中加载的别的信息-或者是链接跳转
            self.progressBar.hidden = NO;
            [self.progressBar setProgress:0 animated:YES];
        }
            break;
        default:
            break;
    }
    return YES;
}
- (void)webViewDidStartLoad:(UIWebView *)webView
{
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [webView stringByEvaluatingJavaScriptFromString:@"document.body.style.webkitTouchCallout='none';"];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
}

#pragma mark - DevWebViewProgressDelegate
- (void)webView:(LSWebView *)webView didReceiveResourceNumber:(NSInteger)resourceNumber totalResources:(NSInteger)totalResources
{
    if (nil == self.progressBar)
    {//
        self.progressBar = [[LSWebProgressBar alloc] initWithFrame:CGRectMake(10, self.webView.bounds.size.height*0.5-2, self.webView.bounds.size.width-20, 4)];
        self.progressBar.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        [self.webView addSubview:self.progressBar];
    }
    
    //Set progress value
    [self.progressBar setProgress:((float)resourceNumber) / ((float)totalResources) animated:NO];
    
    //Reset resource count after finished
    if (resourceNumber == totalResources) {
        webView.resourceCount = 0;
        webView.resourceCompletedCount = 0;
        
        // 加载结束隐藏导航栏
        self.loadFinished = YES;
    }
}


@end
